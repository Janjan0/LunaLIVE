package com.posthog.hogotchi

enum class LunaAction(val label: String, val emoji: String) {
    MILK("Leche", "🍼"),
    WATER("Agua", "💧"),
    BATH("Baño", "🛁"),
    TEDDY("Juguete", "🧸"),
    HUG("Abrazo", "❤️"),
    SLEEP("Dormir", "🌙")
}

enum class LunaMood { IDLE, HAPPY, HUNGRY, THIRSTY, SLEEPY, DIRTY, SAD }

data class LunaState(
    val health: Int = 100,
    val food: Int = 76,
    val water: Int = 82,
    val sleep: Int = 72,
    val clean: Int = 88,
    val happy: Int = 84,
    val coins: Int = 25,
    val xp: Int = 0,
    val level: Int = 1,
    val day: Int = 1,
    val totalLikes: Int = 0,
    val totalGifts: Int = 0,
    val totalCare: Int = 0,
    val emergenciesWon: Int = 0,
    val lastAction: LunaAction? = null,
    val mood: LunaMood = LunaMood.IDLE,
    val crying: Boolean = false,
    val message: String = "¡Luna está feliz de verte!"
) {
    val xpNeeded: Int
        get() = when {
            level <= 2 -> 120 + (level - 1) * 80
            level <= 5 -> (280 * Math.pow(1.18, (level - 3).toDouble())).toInt()
            level <= 10 -> (500 * Math.pow(1.22, (level - 6).toDouble())).toInt()
            else -> (1000 * Math.pow(1.25, (level - 11).toDouble())).toInt()
        }

    val xpPercent: Float get() = (xp.toFloat() / xpNeeded.coerceAtLeast(1)).coerceIn(0f, 1f)

    fun recalcMood(): LunaMood = when {
        health < 25 -> LunaMood.SAD
        food < 25 -> LunaMood.HUNGRY
        water < 25 -> LunaMood.THIRSTY
        sleep < 25 -> LunaMood.SLEEPY
        clean < 25 -> LunaMood.DIRTY
        happy > 78 -> LunaMood.HAPPY
        else -> LunaMood.IDLE
    }
}
