package com.posthog.hogotchi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HogViewModel : ViewModel() {
    private val bus = EventBus()
    private val _state = MutableStateFlow(LunaState())
    val state: StateFlow<LunaState> = _state.asStateFlow()

    private val _reaction = MutableStateFlow(0)
    val reaction: StateFlow<Int> = _reaction.asStateFlow()

    private var messageJob: Job? = null

    init {
        viewModelScope.launch {
            bus.events.collect { event -> handleEvent(event) }
        }
        startDecay()
    }

    private fun startDecay() = viewModelScope.launch {
        while (true) {
            delay(20_000)
            _state.update { old ->
                val next = old.copy(
                    food = (old.food - 2).coerceIn(0, 100),
                    water = (old.water - 2).coerceIn(0, 100),
                    sleep = (old.sleep - 1).coerceIn(0, 100),
                    clean = (old.clean - 1).coerceIn(0, 100),
                    happy = (old.happy - 1).coerceIn(0, 100)
                )
                next.copy(mood = next.recalcMood())
            }
        }
    }

    fun care(action: LunaAction, viewer: String = "Viewer") {
        bus.emit(LiveEvent.Command(action))
        if (viewer.isNotBlank()) bus.emit(LiveEvent.Viewer(viewer))
    }

    fun simulateLikes() = bus.emit(LiveEvent.Like100)
    fun simulateFollow() = bus.emit(LiveEvent.Follow)
    fun simulateGift() = bus.emit(LiveEvent.Gift())
    fun simulateShare() = bus.emit(LiveEvent.Share)

    private fun handleEvent(event: LiveEvent) {
        when (event) {
            LiveEvent.Like100 -> {
                _state.update { it.copy(totalLikes = it.totalLikes + 100, coins = it.coins + 2, message = "💖 ¡100 likes! La comunidad ayuda a Luna") }
                pulse()
            }
            LiveEvent.Follow -> {
                _state.update { it.copy(coins = it.coins + 2, message = "✨ ¡Nuevo seguidor! +2 monedas") }
                pulse()
            }
            LiveEvent.Share -> {
                _state.update { it.copy(coins = it.coins + 1, message = "📣 ¡Compartieron el LIVE! +1 moneda") }
                pulse()
            }
            is LiveEvent.Gift -> {
                _state.update { it.copy(coins = it.coins + event.coins, totalGifts = it.totalGifts + 1, message = "🎁 ¡Regalo recibido! +${event.coins} monedas") }
                pulse()
            }
            is LiveEvent.Viewer -> {
                if (event.name.isNotBlank()) {
                    _state.update { it.copy(message = "👋 ${event.name} está cuidando a Luna") }
                }
            }
            is LiveEvent.Command -> performCare(event.action)
        }
    }

    private fun performCare(action: LunaAction) {
        _state.update { old ->
            if (old.coins <= 0) return@update old.copy(message = "😢 Luna necesita ayuda, pero no quedan monedas")
            val next = when (action) {
                LunaAction.MILK -> old.copy(food = (old.food + 24).coerceAtMost(100), health = (old.health + 2).coerceAtMost(100))
                LunaAction.WATER -> old.copy(water = (old.water + 27).coerceAtMost(100))
                LunaAction.BATH -> old.copy(clean = (old.clean + 35).coerceAtMost(100))
                LunaAction.TEDDY -> old.copy(happy = (old.happy + 22).coerceAtMost(100), food = (old.food - 5).coerceAtLeast(0), sleep = (old.sleep - 5).coerceAtLeast(0))
                LunaAction.HUG -> old.copy(happy = (old.happy + 18).coerceAtMost(100), health = (old.health + 2).coerceAtMost(100))
                LunaAction.SLEEP -> old.copy(sleep = (old.sleep + 30).coerceAtMost(100), health = (old.health + 4).coerceAtMost(100))
            }
            val xpReward = (12 - old.level * 0.35).toInt().coerceAtLeast(4)
            var xp = next.xp + xpReward
            var level = next.level
            var coins = next.coins - 1
            var day = next.day
            var msg = when (action) {
                LunaAction.MILK -> "🍼 Luna tomó su leche"
                LunaAction.WATER -> "💧 Luna tomó agua"
                LunaAction.BATH -> "🛁 ¡Baño listo!"
                LunaAction.TEDDY -> "🧸 Luna juega con su osito"
                LunaAction.HUG -> "❤️ Luna recibió un abrazo"
                LunaAction.SLEEP -> "🌙 Shhh… Luna está durmiendo"
            }
            while (xp >= next.xpNeeded) {
                xp -= next.xpNeeded
                level++
                coins += 5 + level
                day = 1 + ((level - 1) / 3)
                msg = "🎉 ¡Luna llegó al nivel $level! +${5 + level} monedas"
            }
            val final = next.copy(
                coins = coins,
                xp = xp,
                level = level,
                day = day,
                totalCare = next.totalCare + 1,
                lastAction = action,
                message = msg
            )
            final.copy(mood = final.recalcMood())
        }
        pulse()
    }

    private fun pulse() {
        _reaction.update { it + 1 }
        messageJob?.cancel()
        messageJob = viewModelScope.launch {
            delay(1800)
            _state.update { it.copy(message = when (it.mood) {
                LunaMood.HUNGRY -> "🍽 Luna tiene hambre"
                LunaMood.THIRSTY -> "💧 Luna tiene sed"
                LunaMood.SLEEPY -> "😴 Luna tiene sueño"
                LunaMood.DIRTY -> "🫧 Luna necesita un baño"
                LunaMood.SAD -> "🥺 Luna necesita cariño"
                else -> "✨ Luna está contigo"
            }) }
        }
    }
}
