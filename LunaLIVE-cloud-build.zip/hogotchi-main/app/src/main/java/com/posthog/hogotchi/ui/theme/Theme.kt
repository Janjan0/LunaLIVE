package com.posthog.hogotchi.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val LunaPink = Color(0xFFFFB6D5)
val LunaLilac = Color(0xFF9D8CFF)
val LunaBlue = Color(0xFF76C8FF)
val LunaCream = Color(0xFFFFF2C9)
val LunaNight = Color(0xFF17142C)
val LunaNight2 = Color(0xFF29234D)
val LunaPanel = Color(0xB829244A)
val LunaText = Color(0xFFFFF8FF)

private val Scheme = darkColorScheme(
    primary = LunaLilac,
    secondary = LunaPink,
    tertiary = LunaBlue,
    background = LunaNight,
    surface = LunaPanel,
    onPrimary = Color.White,
    onSecondary = LunaNight,
    onBackground = LunaText,
    onSurface = LunaText
)

@Composable
fun HogotchiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
