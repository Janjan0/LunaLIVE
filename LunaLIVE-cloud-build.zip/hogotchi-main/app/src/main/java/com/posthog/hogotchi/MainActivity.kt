package com.posthog.hogotchi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.posthog.hogotchi.ui.theme.HogotchiTheme
import com.posthog.hogotchi.ui.theme.LunaBlue
import com.posthog.hogotchi.ui.theme.LunaCream
import com.posthog.hogotchi.ui.theme.LunaLilac
import com.posthog.hogotchi.ui.theme.LunaNight
import com.posthog.hogotchi.ui.theme.LunaNight2
import com.posthog.hogotchi.ui.theme.LunaPink
import com.posthog.hogotchi.ui.theme.LunaText
import kotlin.math.min
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val viewModel: HogViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HogotchiTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = LunaNight) {
                    LunaLiveScreen(viewModel)
                }
            }
        }
    }
}

@Composable
private fun LunaLiveScreen(viewModel: HogViewModel) {
    val state by viewModel.state.collectAsState()
    val reaction by viewModel.reaction.collectAsState()
    var simulatorOpen by remember { mutableStateOf(false) }
    val pulse by animateFloatAsState(
        targetValue = if (reaction % 2 == 0) 1f else 1.045f,
        animationSpec = tween(160, easing = FastOutSlowInEasing),
        label = "reactionPulse"
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF16132D), Color(0xFF322A58), Color(0xFF17142C))
                )
            )
    ) {
        val portrait = maxHeight > maxWidth
        val compact = maxWidth < 380.dp
        val lunaSize = if (portrait) minOf(maxWidth * 0.43f, 250.dp) else minOf(maxHeight * 0.46f, 300.dp)
        val buttonSize = if (compact) 58.dp else if (portrait) 66.dp else 70.dp

        NurseryBackdrop(portrait)

        TopHud(state, onSimulator = { simulatorOpen = !simulatorOpen })

        if (portrait) {
            PortraitStats(state)
        } else {
            LandscapeStats(state, Modifier.align(Alignment.CenterEnd))
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = if (portrait) 150.dp else 80.dp,
                    bottom = 24.dp,
                    start = if (portrait) 12.dp else 90.dp,
                    end = if (portrait) 12.dp else 105.dp
                ),
            contentAlignment = Alignment.Center
        ) {
            LunaGlow(Modifier.size(lunaSize * 1.55f))
            LunaPet(
                modifier = Modifier
                    .size(lunaSize)
                    .scale(pulse),
                action = state.lastAction,
                mood = state.mood,
                crying = state.crying
            )

            RadialAction(
                action = LunaAction.MILK,
                modifier = Modifier.align(Alignment.TopStart).offset(x = buttonSize * 0.35f, y = buttonSize * 0.15f),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.MILK) }
            )
            RadialAction(
                action = LunaAction.WATER,
                modifier = Modifier.align(Alignment.CenterStart).offset(x = 0.dp, y = if (portrait) (-8).dp else (-22).dp),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.WATER) }
            )
            RadialAction(
                action = LunaAction.BATH,
                modifier = Modifier.align(Alignment.BottomStart).offset(x = buttonSize * 0.35f, y = -buttonSize * 0.15f),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.BATH) }
            )
            RadialAction(
                action = LunaAction.TEDDY,
                modifier = Modifier.align(Alignment.TopEnd).offset(x = -buttonSize * 0.35f, y = buttonSize * 0.15f),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.TEDDY) }
            )
            RadialAction(
                action = LunaAction.HUG,
                modifier = Modifier.align(Alignment.CenterEnd).offset(x = 0.dp, y = if (portrait) (-8).dp else (-22).dp),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.HUG) }
            )
            RadialAction(
                action = LunaAction.SLEEP,
                modifier = Modifier.align(Alignment.BottomEnd).offset(x = -buttonSize * 0.35f, y = -buttonSize * 0.15f),
                size = buttonSize,
                onClick = { viewModel.care(LunaAction.SLEEP) }
            )

            MessageBubble(
                state.message,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = if (portrait) 18.dp else 12.dp)
            )
        }

        if (simulatorOpen) {
            SimulatorPanel(
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 66.dp, end = 12.dp),
                onLikes = viewModel::simulateLikes,
                onFollow = viewModel::simulateFollow,
                onGift = viewModel::simulateGift,
                onShare = viewModel::simulateShare,
                onClose = { simulatorOpen = false }
            )
        }
    }
}

@Composable
private fun NurseryBackdrop(portrait: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        // moon
        drawCircle(Color(0xFFFFEBC2), radius = min(w, h) * 0.065f, center = Offset(w * 0.78f, h * 0.17f))
        drawCircle(Color(0xFF6B5C94).copy(alpha = 0.55f), radius = min(w, h) * 0.065f, center = Offset(w * 0.81f, h * 0.145f))
        // window
        val winW = w * if (portrait) 0.34f else 0.25f
        val winH = h * if (portrait) 0.20f else 0.30f
        val left = w * 0.5f - winW / 2
        val top = if (portrait) h * 0.13f else h * 0.10f
        drawRoundRect(Color(0xFF5B527F), topLeft = Offset(left - 12, top - 12), size = Size(winW + 24, winH + 24), cornerRadius = androidx.compose.ui.geometry.CornerRadius(28f, 28f))
        drawRoundRect(Color(0xFF1C2347), topLeft = Offset(left, top), size = Size(winW, winH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f, 20f))
        drawLine(Color(0xFF9D8FC8), Offset(left + winW / 2, top), Offset(left + winW / 2, top + winH), strokeWidth = 5f)
        drawLine(Color(0xFF9D8FC8), Offset(left, top + winH / 2), Offset(left + winW, top + winH / 2), strokeWidth = 5f)

        // stars
        val stars = listOf(Offset(.10f,.12f),Offset(.20f,.24f),Offset(.35f,.08f),Offset(.64f,.07f),Offset(.90f,.29f),Offset(.13f,.42f),Offset(.84f,.42f))
        stars.forEachIndexed { i, p ->
            val r = if (i % 2 == 0) 4f else 2.5f
            drawCircle(Color(0xFFFFEFC7).copy(alpha = .75f), r, Offset(w*p.x,h*p.y))
        }

        // floor/rug
        drawOval(Color(0xFF9A83C7).copy(alpha = .25f), topLeft = Offset(w*.17f,h*.68f), size = Size(w*.66f,h*.24f))
        drawOval(Color(0xFFEAB5D5).copy(alpha = .15f), topLeft = Offset(w*.24f,h*.72f), size = Size(w*.52f,h*.15f))

        // plants / furniture silhouettes
        drawRoundRect(Color(0xFF201B3C), topLeft = Offset(w*.03f,h*.56f), size = Size(w*.12f,h*.20f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f,22f))
        drawCircle(Color(0xFF5D8C7A), min(w,h)*.055f, Offset(w*.08f,h*.52f))
        drawCircle(Color(0xFF6BA08A), min(w,h)*.045f, Offset(w*.14f,h*.54f))
        drawRoundRect(Color(0xFF201B3C), topLeft = Offset(w*.85f,h*.54f), size = Size(w*.12f,h*.22f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(22f,22f))
        drawRoundRect(Color(0xFF3D335D), topLeft = Offset(w*.40f,h*.83f), size = Size(w*.20f,h*.10f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f,18f))
    }
}

@Composable
private fun TopHud(state: LunaState, onSimulator: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCCFF5C78)).padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("●", color = Color.White, fontSize = 10.sp)
            Spacer(Modifier.width(5.dp))
            Text("LIVE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xAA2A2448))) {
            Row(Modifier.padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🌙", fontSize = 17.sp)
                Spacer(Modifier.width(5.dp))
                Column {
                    Text("Luna", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Niña", color = Color(0xFFCFC7E8), fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xAA2A2448))) {
            Text("Día ${state.day}  •  Nv ${state.level}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = LunaCream, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xAA2A2448))) {
            Text("🪙 ${state.coins}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = LunaCream, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "SIM",
            modifier = Modifier.clip(CircleShape).background(LunaLilac).clickable { onSimulator() }.padding(horizontal = 10.dp, vertical = 8.dp),
            color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun PortraitStats(state: LunaState) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        MiniStat("❤️", state.health)
        MiniStat("🍽", state.food)
        MiniStat("💧", state.water)
        MiniStat("😴", state.sleep)
        MiniStat("🫧", state.clean)
        MiniStat("💕", state.happy)
    }
}

@Composable
private fun MiniStat(icon: String, value: Int) {
    Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), colors = CardDefaults.cardColors(containerColor = Color(0x99282249))) {
        Column(Modifier.padding(vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 12.sp)
            Text("$value", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LandscapeStats(state: LunaState, modifier: Modifier) {
    Card(
        modifier = modifier.fillMaxHeight().width(82.dp).padding(vertical = 84.dp, end = 8.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xA82A2448))
    ) {
        Column(Modifier.fillMaxSize().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("LUNA", color = LunaPink, fontWeight = FontWeight.Black, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            StatLine("❤️", state.health)
            StatLine("🍽", state.food)
            StatLine("💧", state.water)
            StatLine("😴", state.sleep)
            StatLine("🫧", state.clean)
            StatLine("💕", state.happy)
            Spacer(Modifier.weight(1f))
            Text("XP", color = Color(0xFFBEB5D9), fontSize = 9.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            LinearProgressIndicator(progress = { state.xpPercent }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = LunaLilac, trackColor = Color(0x334F466F))
        }
    }
}

@Composable
private fun StatLine(icon: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text(icon, fontSize = 14.sp)
        LinearProgressIndicator(progress = { value / 100f }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape), color = if (value < 30) Color(0xFFFF7694) else LunaLilac, trackColor = Color(0x334F466F))
        Text("$value", color = Color(0xFFDAD2EA), fontSize = 8.sp)
    }
}

@Composable
private fun LunaGlow(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "glow")
    val alpha by transition.animateFloat(0.16f, 0.28f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "glowAlpha")
    Box(modifier = modifier.clip(CircleShape).background(Color(0xFFFFD6E9).copy(alpha = alpha)))
}

@Composable
private fun LunaPet(modifier: Modifier, action: LunaAction?, mood: LunaMood, crying: Boolean) {
    val transition = rememberInfiniteTransition(label = "lunaIdle")
    val bob by transition.animateFloat(-5f, 5f, infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    var blink by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3600)
            blink = true
            delay(140)
            blink = false
        }
    }
    val actionScale by animateFloatAsState(if (action == null) 1f else 1.05f, tween(220), label = "actionScale")

    Canvas(modifier = modifier.offset(y = bob.dp).scale(actionScale)) {
        val w = size.width
        val h = size.height
        val cx = w / 2
        val headR = w * .31f
        val headY = h * .34f

        // shadow
        drawOval(Color.Black.copy(alpha = .18f), Offset(w*.18f,h*.84f), Size(w*.64f,h*.10f))
        // legs / pajama body
        drawRoundRect(Color(0xFFFFAFCF), Offset(w*.27f,h*.55f), Size(w*.46f,h*.30f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*.12f,w*.12f))
        drawCircle(Color(0xFFFFC3DD), w*.08f, Offset(w*.33f,h*.82f))
        drawCircle(Color(0xFFFFC3DD), w*.08f, Offset(w*.67f,h*.82f))
        // moon/star pattern
        drawCircle(Color(0xFFFFE8A9), w*.026f, Offset(w*.39f,h*.67f))
        drawCircle(Color(0xFFFFE8A9), w*.02f, Offset(w*.59f,h*.73f))
        drawCircle(Color(0xFF9F8CFF), w*.018f, Offset(w*.54f,h*.64f))

        // arms
        drawRoundRect(Color(0xFFFFB9D5), Offset(w*.20f,h*.58f), Size(w*.16f,h*.12f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*.08f,w*.08f))
        drawRoundRect(Color(0xFFFFB9D5), Offset(w*.64f,h*.58f), Size(w*.16f,h*.12f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w*.08f,w*.08f))

        // head + ears
        drawCircle(Color(0xFFFFD4B8), headR, Offset(cx,headY))
        drawCircle(Color(0xFFFFC3AA), headR*.28f, Offset(cx-headR*.82f,headY+headR*.10f))
        drawCircle(Color(0xFFFFC3AA), headR*.28f, Offset(cx+headR*.82f,headY+headR*.10f))
        // hair
        val hair = Path().apply {
            moveTo(cx-headR*.78f, headY-headR*.42f)
            quadraticTo(cx-headR*.35f, headY-headR*1.15f, cx, headY-headR*.58f)
            quadraticTo(cx+headR*.35f, headY-headR*1.12f, cx+headR*.78f, headY-headR*.42f)
            quadraticTo(cx+headR*.55f, headY-headR*.72f, cx+headR*.2f, headY-headR*.48f)
            quadraticTo(cx, headY-headR*.78f, cx-headR*.2f, headY-headR*.48f)
            quadraticTo(cx-headR*.55f, headY-headR*.72f, cx-headR*.78f, headY-headR*.42f)
            close()
        }
        drawPath(hair, Color(0xFFE6C38E))
        // bow
        drawOval(Color(0xFFFF79AE), Offset(cx+headR*.35f,headY-headR*.92f), Size(headR*.55f,headR*.34f))
        drawOval(Color(0xFFFF79AE), Offset(cx+headR*.02f,headY-headR*.92f), Size(headR*.55f,headR*.34f))
        drawCircle(Color(0xFFFFC2DA), headR*.12f, Offset(cx+headR*.31f,headY-headR*.75f))

        // eyes
        val eyeY = headY + headR*.08f
        if (blink) {
            drawLine(Color(0xFF342A50), Offset(cx-headR*.46f,eyeY), Offset(cx-headR*.20f,eyeY), strokeWidth = 7f, cap = StrokeCap.Round)
            drawLine(Color(0xFF342A50), Offset(cx+headR*.20f,eyeY), Offset(cx+headR*.46f,eyeY), strokeWidth = 7f, cap = StrokeCap.Round)
        } else {
            drawOval(Color.White, Offset(cx-headR*.53f,eyeY-headR*.22f), Size(headR*.38f,headR*.55f))
            drawOval(Color.White, Offset(cx+headR*.15f,eyeY-headR*.22f), Size(headR*.38f,headR*.55f))
            drawCircle(Color(0xFF6D59C7), headR*.13f, Offset(cx-headR*.34f,eyeY+headR*.03f))
            drawCircle(Color(0xFF6D59C7), headR*.13f, Offset(cx+headR*.34f,eyeY+headR*.03f))
            drawCircle(Color.White, headR*.045f, Offset(cx-headR*.38f,eyeY-headR*.05f))
            drawCircle(Color.White, headR*.045f, Offset(cx+headR*.30f,eyeY-headR*.05f))
        }
        drawCircle(Color(0xFFFF9EAF).copy(alpha = .7f), headR*.12f, Offset(cx-headR*.63f,headY+headR*.30f))
        drawCircle(Color(0xFFFF9EAF).copy(alpha = .7f), headR*.12f, Offset(cx+headR*.63f,headY+headR*.30f))
        // mouth by mood
        if (mood == LunaMood.SAD || crying) {
            drawArc(Color(0xFF7D4563), Offset(cx-headR*.11f,headY+headR*.36f), Size(headR*.22f,headR*.13f), 200f, 140f, false, style = Stroke(5f))
            drawCircle(Color(0xFF7AB9FF), headR*.05f, Offset(cx-headR*.62f,headY+headR*.52f))
            drawCircle(Color(0xFF7AB9FF), headR*.05f, Offset(cx+headR*.62f,headY+headR*.52f))
        } else {
            drawArc(Color(0xFF7D4563), Offset(cx-headR*.11f,headY+headR*.30f), Size(headR*.22f,headR*.15f), 20f, 140f, false, style = Stroke(5f))
        }

        // teddy appears for toy/hug action
        if (action == LunaAction.TEDDY || action == LunaAction.HUG) {
            drawCircle(Color(0xFFC58B6E), w*.13f, Offset(cx, h*.61f))
            drawCircle(Color(0xFFC58B6E), w*.045f, Offset(cx-w*.09f,h*.55f))
            drawCircle(Color(0xFFC58B6E), w*.045f, Offset(cx+w*.09f,h*.55f))
            drawCircle(Color(0xFF3E314E), w*.012f, Offset(cx-w*.04f,h*.60f))
            drawCircle(Color(0xFF3E314E), w*.012f, Offset(cx+w*.04f,h*.60f))
        }
    }
}

@Composable
private fun RadialAction(action: LunaAction, modifier: Modifier, size: Dp, onClick: () -> Unit) {
    val bg = when (action) {
        LunaAction.MILK -> Color(0xFFFFC4D8)
        LunaAction.WATER -> Color(0xFFA7DDFF)
        LunaAction.BATH -> Color(0xFFB7E7E4)
        LunaAction.TEDDY -> Color(0xFFFFD2A7)
        LunaAction.HUG -> Color(0xFFFFAFC9)
        LunaAction.SLEEP -> Color(0xFFC5B9FF)
    }
    Card(
        modifier = modifier.size(size).clickable { onClick() },
        shape = CircleShape,
        colors = CardDefaults.cardColors(containerColor = bg.copy(alpha = .96f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 7.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(action.emoji, fontSize = if (size < 62.dp) 20.sp else 24.sp)
            Text(action.label, color = Color(0xFF4A3658), fontSize = if (size < 62.dp) 7.sp else 8.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun MessageBubble(text: String, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = text.isNotBlank(), modifier = modifier, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xDD201B3C))) {
            Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = LunaText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SimulatorPanel(
    modifier: Modifier,
    onLikes: () -> Unit,
    onFollow: () -> Unit,
    onGift: () -> Unit,
    onShare: () -> Unit,
    onClose: () -> Unit
) {
    Card(modifier = modifier.width(210.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xF52A2448))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Simulador LIVE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text("×", color = Color(0xFFCEC5E5), fontSize = 18.sp, modifier = Modifier.clickable { onClose() })
            }
            Text("Prueba eventos sin TikTok", color = Color(0xFFBEB5D9), fontSize = 9.sp)
            SimButton("💖  +100 likes", onLikes)
            SimButton("✨  Follow", onFollow)
            SimButton("🎁  Regalo +10", onGift)
            SimButton("📣  Compartir", onShare)
        }
    }
}

@Composable
private fun SimButton(text: String, onClick: () -> Unit) {
    Text(text, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF443A68)).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 9.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
}
