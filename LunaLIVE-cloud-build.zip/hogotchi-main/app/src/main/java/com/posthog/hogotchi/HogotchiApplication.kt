package com.posthog.hogotchi

import android.app.Application

class HogotchiApplication : Application()
