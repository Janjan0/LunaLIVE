# Luna LIVE — Android prototype

This project is a clean Android/Jetpack Compose conversion of the original Hogotchi base into a Luna LIVE virtual-baby game.

## What is already implemented

- Luna centered in a cozy night nursery.
- Six radial care actions: Leche, Agua, Baño, Juguete, Abrazo, Dormir.
- Real idle bob animation and automatic blinking.
- Action pulse animation and contextual visual reactions.
- Teddy appears during toy/hug interactions.
- Health, hunger, thirst, sleep, hygiene and happiness.
- Coins, XP, levels and progressively harder progression.
- Stat decay over time.
- LIVE HUD with day, level and coins.
- Portrait and landscape layouts without forcing device rotation.
- Local LIVE simulator: +100 likes, follow, gift and share.
- EventBus/GameState/GameEngine boundary for future TikTok integration.
- No Firebase or PostHog account/configuration is required to run the game prototype.

## Build

Open the project in Android Studio and run the `app` configuration.

Or from a machine with internet access and Android SDK/Gradle available:

```bash
./gradlew assembleDebug
```

The debug APK will be generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## TikTok integration boundary

`TikTokAdapter.kt` defines the boundary for a future backend connector. A real TikTok connector should translate external LIVE events into `LiveEvent` values. Secrets/tokens should remain server-side; the Android app should only receive normalized game events.

The built-in `SimulationTikTokAdapter` demonstrates the same event path without requiring TikTok.

## License note

This project started from the uploaded Hogotchi source, which states MIT licensing. The Luna-specific code in this modified project is intended to remain compatible with that licensing model.
