package com.posthog.hogotchi

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

sealed interface LiveEvent {
    data object Like100 : LiveEvent
    data object Follow : LiveEvent
    data object Share : LiveEvent
    data class Gift(val coins: Int = 10) : LiveEvent
    data class Command(val action: LunaAction) : LiveEvent
    data class Viewer(val name: String) : LiveEvent
}

class EventBus {
    private val _events = MutableSharedFlow<LiveEvent>(extraBufferCapacity = 64)
    val events = _events.asSharedFlow()
    fun emit(event: LiveEvent) { _events.tryEmit(event) }
}
