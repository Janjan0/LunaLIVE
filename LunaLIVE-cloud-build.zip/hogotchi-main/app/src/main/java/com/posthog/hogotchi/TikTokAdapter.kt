package com.posthog.hogotchi

/**
 * Boundary for a real TikTok LIVE connector.
 * The game never talks directly to TikTok; an adapter translates external
 * events into LiveEvent values and pushes them through EventBus.
 */
interface TikTokAdapter {
    fun connect()
    fun disconnect()
    fun isConnected(): Boolean
}

/** Local adapter used by the SIM button in the app. */
class SimulationTikTokAdapter(private val bus: EventBus) : TikTokAdapter {
    private var connected = false

    override fun connect() { connected = true }
    override fun disconnect() { connected = false }
    override fun isConnected(): Boolean = connected

    fun like100() = bus.emit(LiveEvent.Like100)
    fun follow() = bus.emit(LiveEvent.Follow)
    fun share() = bus.emit(LiveEvent.Share)
    fun gift(coins: Int = 10) = bus.emit(LiveEvent.Gift(coins))
    fun command(action: LunaAction) = bus.emit(LiveEvent.Command(action))
}
